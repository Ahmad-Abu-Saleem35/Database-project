package JavaFXClasses;

import Layouts.*;
import TableViews.CustomerTableView;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

import java.sql.SQLException;

public class SidePane extends BorderPane {
    Button[] bt = new Button[9];
    CustomerLayout customerLayout = new CustomerLayout();
    EmployeeLayout employeeLayout = new EmployeeLayout();
    PaymentLayout paymentLayout = new PaymentLayout();
    RentalLayout rentalLayout = new RentalLayout();
    ReportLayout reportLayout = new ReportLayout();
    InsuranceLayout insuranceLayout = new InsuranceLayout();
    CarLayout carLayout = new CarLayout();
    BorderPane dashPane = new BorderPane();
    ScrollPane scrollPane = new ScrollPane();

    public SidePane() throws SQLException {
        Button helpButton = new Button("?");
        Style.style(helpButton);
        VBox vBox2 = Style.help();
        helpButton.setOnAction(e->{
            this.setCenter(vBox2);
        });
        this.setCenter(dashPane);
        HBox hBox = new HBox();
        CarList[] carLists = new CarList[5];
        for(int i=0;i<carLists.length;i++) {
            carLists[i] = new CarList();
            hBox.getChildren().add(carLists[i]);
        }
        carLists[0].info("Total Cars",10);
        carLists[1].info("Available Cars",5);
        carLists[2].info("Rented Cars",5);
        carLists[3].info("Total Employees",4);
        carLists[4].info("Total Customers",10);
        Style.styleDash(carLists[0],"lightGreen");
        Style.styleDash(carLists[1],"red");
        Style.styleDash(carLists[2],"deepSkyBlue");
        Style.styleDash(carLists[3],"darkblue");
        Style.styleDash(carLists[4],"darkOrange");
        hBox.setPadding(new Insets(10,10,10,10));
        hBox.setAlignment(Pos.CENTER);

        // -------------------

        hBox.setSpacing(30);
        dashPane.setTop(hBox);
        ImageView backgroundImage = Style.backgroundImage("C:/Users/ibrah/Downloads/2018_bmw_i8_roadster_4k-2560x1440.jpg");
        backgroundImage.fitWidthProperty().bind(this.widthProperty());
        backgroundImage.fitHeightProperty().bind(this.heightProperty());
        LineChart<Number,Number> lineChart = createLineChart();
        Style.styleChart(lineChart);
        PieChart pieChart = createPieChart();
        Style.styleChart(pieChart);
        VBox vBox = new VBox();
        vBox.setAlignment(Pos.CENTER);
        vBox.setSpacing(70);
        CustomerTableView customerTableView = new CustomerTableView();
        customerTableView.setMaxSize(866,400);
        scrollPane.setContent(vBox);
        vBox.getChildren().addAll(hBox,lineChart,pieChart,customerTableView);
        vBox.setPadding(new Insets(40,40,40,100));
        dashPane.setCenter(scrollPane);
        this.setStyle("-fx-background-color: rgb(159,189,165,255);");
        VBox mainMenu = Style.createSideButtons(bt);
        this.setLeft(mainMenu);
        this.setStyle("-fx-background-color:white;");
        handleCustomer();
        handleDashBoard();
        handleEmployee();
        handleInsurance();
        handleReport();
        handleRental();
        handlePayment();
        handleCar();
    }

    //         String[] label = {"User","Dashboard","Customer","Payment","Rental","Car","Employee","Insurance","Reports"};
    public void handleDashBoard(){
        bt[1].setOnAction(e->{
            this.setCenter(dashPane);
        });
    }
    public void handleCustomer(){
        bt[2].setOnAction(e->{
            this.setCenter(customerLayout);
        });
    }
    public void handleEmployee(){
        bt[6].setOnAction(e->{
            this.setCenter(employeeLayout);
        });
    }
    public void handlePayment(){
        bt[3].setOnAction(e->{
            this.setCenter(paymentLayout);
        });
    }
    public void handleInsurance(){
        bt[7].setOnAction(e->{
            this.setCenter(insuranceLayout);
        });
    }
    public void handleRental(){
        bt[4].setOnAction(e->{
            this.setCenter(rentalLayout);
        });
    }
    public void handleReport(){
        bt[8].setOnAction(e->{
            this.setCenter(reportLayout);
        });
    }
    public void handleCar(){
        bt[5].setOnAction(e->{
            this.setCenter(carLayout);
        });

    }



    private LineChart<Number, Number> createLineChart() {
        // Defining the x-axis
        NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel("Number of Months");

        // Defining the y-axis
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Stock Price");

        // Creating the line chart with the specified axes
        LineChart<Number, Number> lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setTitle("Stock Monitoring, 2024");

        // Preparing the data series
        XYChart.Series<Number, Number> series = new XYChart.Series<>();
        series.setName("Rental Sales");

        series.getData().add(new XYChart.Data<>(1, 23));
        series.getData().add(new XYChart.Data<>(2, 14));
        series.getData().add(new XYChart.Data<>(3, 15));
        series.getData().add(new XYChart.Data<>(4, 24));
        series.getData().add(new XYChart.Data<>(5, 34));
        series.getData().add(new XYChart.Data<>(6, 36));
        series.getData().add(new XYChart.Data<>(7, 22));
        series.getData().add(new XYChart.Data<>(8, 45));
        series.getData().add(new XYChart.Data<>(9, 43));
        series.getData().add(new XYChart.Data<>(10, 17));
        series.getData().add(new XYChart.Data<>(11, 29));
        series.getData().add(new XYChart.Data<>(12, 25));

        // Adding the series to the chart
        lineChart.getData().add(series);

        return lineChart;
    }
    private PieChart createPieChart() {
        // Preparing the data
        PieChart.Data slice1 = new PieChart.Data("Toyota", 30);
        PieChart.Data slice2 = new PieChart.Data("Nessan", 25);
        PieChart.Data slice3 = new PieChart.Data("Hyundai", 20);
        PieChart.Data slice4 = new PieChart.Data("BMW", 15);
        PieChart.Data slice5 = new PieChart.Data("Other", 10);

        // Creating the pie chart and adding data
        PieChart pieChart = new PieChart();
        pieChart.getData().add(slice1);
        pieChart.getData().add(slice2);
        pieChart.getData().add(slice3);
        pieChart.getData().add(slice4);
        pieChart.getData().add(slice5);

        // Setting the title of the pie chart
        pieChart.setTitle("Distribution of Car Types Available");

        return pieChart;
    }


}
