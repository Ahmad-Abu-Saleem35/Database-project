package JavaFXClasses;

import ERDClasses.Employee;
import SqlClass.DatabaseConnection;
import SqlClass.EmployeeDAO;
import javafx.application.Application;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

import java.sql.SQLException;


public class Main extends Application {
    private static ImageView backgroundImage;
    private static Employee currentEmpolyee;
    EmployeeDAO employeeDAO = new EmployeeDAO(DatabaseConnection.getConnection());
    public Main() throws SQLException {
    }

    public static void main(String[] args){
        launch();
    }
    private final BorderPane root = new BorderPane();
    private static final SidePane sidePane;

    static {
        try {
            sidePane = new SidePane();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    Login login = new Login();
    @Override
    public void start(Stage stage) throws Exception {
        Scene scene = new Scene(login,600,450);
        scene.getStylesheets().add(getClass().getResource("/tableView.css").toExternalForm());

        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);

        login.getBt3().setOnAction(e->{
            stage.close();
        });
        login.getBt1().setOnAction(e->{
            handleLogin(login.getID(),login.getPasswordField(),stage);
        });
    }
    public void handleLogin(TextField ID,TextField passwordField,Stage stage){
            if(ID.getText().isEmpty() || passwordField.getText().isEmpty()){
                login.getLabel().setText("All Fields are required");
                return;
            }
            if(login.getLoginDAO().selectLogin(Integer.parseInt(ID.getText()), passwordField.getText())){
                currentEmpolyee = employeeDAO.searchEmployeeById(Integer.parseInt(ID.getText()));
                stage.close();
                Stage stage1 = new Stage();
                Scene scene1 = new Scene(sidePane);
                scene1.getStylesheets().add(getClass().getResource("/tableView.css").toExternalForm());
                stage1.setScene(scene1);
                stage1.setMaximized(true);
                stage1.show();

            }else{
                login.getLabel().setText("Password doesn't exist");
            }
    }
    public static Employee getEmpolyee(){
        return currentEmpolyee;
    }

}