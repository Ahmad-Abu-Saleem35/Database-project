package JavaFXClasses;

import java.time.LocalDate;
import java.time.Period;

public class Manager {
    public static int calculateAge(LocalDate birthDate) {
        // Get the current date
        LocalDate currentDate = LocalDate.now();

        // Calculate the period between the birth date and the current date
        Period period = Period.between(birthDate, currentDate);

        // Return the years from the period
        return period.getYears();
    }
    public static boolean isValidAge(int age){
        return age >= 18;
    }
    public static boolean isNum(String n){
        try{
            double num = Double.parseDouble(n);
            return true;
        }catch (NullPointerException ex){
            return false;
        }
    }
}
