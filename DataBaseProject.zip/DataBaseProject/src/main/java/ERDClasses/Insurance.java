package ERDClasses;

import javafx.beans.property.*;

import java.util.Objects;

public class Insurance {
    private IntegerProperty ID;
    private StringProperty Type;
    private IntegerProperty car_Id;

    public Insurance(int insuranceId, String insuranceType, int car_Id) {
        this.ID = new SimpleIntegerProperty(insuranceId);
        this.Type = new SimpleStringProperty(insuranceType);
        this.car_Id = new SimpleIntegerProperty(car_Id);
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        Insurance insurance = (Insurance) object;
        return ID.get() == insurance.ID.get() && Objects.equals(Type.get(), insurance.Type.get());
    }

    @Override
    public int hashCode() {
        return Objects.hash(ID.get(), Type.get());
    }

    public int getCar_Id() {
        return car_Id.get();
    }

    public IntegerProperty car_IdProperty() {
        return car_Id;
    }

    public void setCar_Id(int car_Id) {
        this.car_Id.set(car_Id);
    }

    public int getID() {
        return ID.get();
    }

    public IntegerProperty IDProperty() {
        return ID;
    }

    public void setID(int ID) {
        this.ID.set(ID);
    }

    public String getType() {
        return Type.get();
    }

    public StringProperty typeProperty() {
        return Type;
    }

    public void setType(String Type) {
        this.Type.set(Type);
    }
}
