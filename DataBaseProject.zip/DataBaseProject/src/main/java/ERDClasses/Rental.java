package ERDClasses;

import javafx.beans.property.*;
import java.sql.Date;
import java.util.Objects;

public class Rental {
    private ObjectProperty<Date> rentDate;
    private ObjectProperty<Date> returnDate;
    private IntegerProperty rentID;
    private StringProperty cancellation;
    private IntegerProperty employee_Id;
    private IntegerProperty car_Id;
    private IntegerProperty payment_ID;

    public Rental(java.sql.Date rentDate, java.sql.Date returnDate, int rentID, String cancellation, int employee_Id, int car_Id, int payment_ID) {
        this.rentDate = new SimpleObjectProperty<>(rentDate);
        this.returnDate = new SimpleObjectProperty<>(returnDate);
        this.rentID = new SimpleIntegerProperty(rentID);
        this.cancellation = new SimpleStringProperty(cancellation);
        this.employee_Id = new SimpleIntegerProperty(employee_Id);
        this.car_Id = new SimpleIntegerProperty(car_Id);
        this.payment_ID = new SimpleIntegerProperty(payment_ID);
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        Rental rental = (Rental) object;
        return Objects.equals(rentDate, rental.rentDate) && Objects.equals(returnDate, rental.returnDate) && Objects.equals(rentID, rental.rentID) && Objects.equals(cancellation, rental.cancellation) && Objects.equals(employee_Id, rental.employee_Id) && Objects.equals(car_Id, rental.car_Id) && Objects.equals(payment_ID, rental.payment_ID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(rentDate, returnDate, rentID, cancellation, employee_Id, car_Id, payment_ID);
    }

    public int getPayment_ID() {
        return payment_ID.get();
    }

    public IntegerProperty payment_IDProperty() {
        return payment_ID;
    }

    public void setPayment_ID(int payment_ID) {
        this.payment_ID.set(payment_ID);
    }

    public java.sql.Date getRentDate() {
        return rentDate.get();
    }

    public ObjectProperty<Date> rentDateProperty() {
        return rentDate;
    }

    public void setRentDate(Date rentDate) {
        this.rentDate.set(rentDate);
    }

    public java.sql.Date getReturnDate() {
        return returnDate.get();
    }

    public ObjectProperty<Date> returnDateProperty() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate.set(returnDate);
    }

    public int getRentID() {
        return rentID.get();
    }

    public IntegerProperty rentIDProperty() {
        return rentID;
    }

    public void setRentID(int rentID) {
        this.rentID.set(rentID);
    }

    public String getCancellation() {
        return cancellation.get();
    }

    public StringProperty cancellationProperty() {
        return cancellation;
    }

    public void setCancellation(String cancellation) {
        this.cancellation.set(cancellation);
    }

    public int getEmployee_Id() {
        return employee_Id.get();
    }

    public IntegerProperty employee_IdProperty() {
        return employee_Id;
    }

    public void setEmployee_Id(int employee_Id) {
        this.employee_Id.set(employee_Id);
    }

    public int getCar_Id() {
        return car_Id.get();
    }

    public IntegerProperty car_IdProperty() {
        return car_Id;
    }

    public void setCar_Id(int car_Id) {
        this.car_Id.set(car_Id);
    }
}
