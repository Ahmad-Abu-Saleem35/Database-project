package ERDClasses;

import javafx.beans.property.*;
import java.sql.Date;

public class Payment {
    private DoubleProperty amount; // Change from IntegerProperty to DoubleProperty
    private IntegerProperty paymentID;
    private DoubleProperty downPay; // Change from IntegerProperty to DoubleProperty
    private StringProperty paymentMethod;
    private ObjectProperty<Date> paydate; // Change to java.sql.Date
    private IntegerProperty customerId;

    public Payment(double amount, int paymentID, double downPay, String paymentMethod, Date paydate,int customerID) {
        this.amount = new SimpleDoubleProperty(amount); // Use SimpleDoubleProperty instead of SimpleIntegerProperty
        this.paymentID = new SimpleIntegerProperty(paymentID);
        this.downPay = new SimpleDoubleProperty(downPay); // Use SimpleDoubleProperty instead of SimpleIntegerProperty
        this.paymentMethod = new SimpleStringProperty(paymentMethod);
        this.paydate = new SimpleObjectProperty<>(paydate);
        this.customerId=new SimpleIntegerProperty(customerID);
    }

    public double getAmount() {
        return amount.get();
    }

    public DoubleProperty amountProperty() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount.set(amount);
    }

    public int getPaymentID() {
        return paymentID.get();
    }

    public IntegerProperty paymentIDProperty() {
        return paymentID;
    }

    public void setPaymentID(int paymentID) {
        this.paymentID.set(paymentID);
    }

    public double getDownPay() {
        return downPay.get();
    }

    public DoubleProperty downPayProperty() {
        return downPay;
    }

    public void setDownPay(double downPay) {
        this.downPay.set(downPay);
    }

    public String getPaymentMethod() {
        return paymentMethod.get();
    }

    public StringProperty paymentMethodProperty() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod.set(paymentMethod);
    }

    public Date getPaydate() {
        return paydate.get();
    }

    public ObjectProperty<Date> paydateProperty() {
        return paydate;
    }

    public int getCustomerId() {
        return customerId.get();
    }

    public IntegerProperty customerIdProperty() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId.set(customerId);
    }

    public void setPaydate(Date paydate) {
        this.paydate.set(paydate);
    }
}
