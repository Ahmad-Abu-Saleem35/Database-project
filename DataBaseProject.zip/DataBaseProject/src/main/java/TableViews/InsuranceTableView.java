package TableViews;

import ERDClasses.Insurance;
import javafx.geometry.Insets;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class InsuranceTableView extends TableView<Insurance> {

    public InsuranceTableView() {
        this.setPadding(new Insets(20,20,20,20));
        // Define columns
        TableColumn<Insurance, Integer> insuranceIdCol = new TableColumn<>("Insurance ID");
        insuranceIdCol.setCellValueFactory(new PropertyValueFactory<>("insuranceId"));
        insuranceIdCol.setPrefWidth(405);

        TableColumn<Insurance, String> insuranceTypeCol = new TableColumn<>("Insurance Type");
        insuranceTypeCol.setCellValueFactory(new PropertyValueFactory<>("insuranceType"));
        insuranceTypeCol.setPrefWidth(405);
        // Add columns to table
        this.getColumns().addAll(insuranceIdCol, insuranceTypeCol);
    }
}
