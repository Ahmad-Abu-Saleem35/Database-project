package TableViews;

import ERDClasses.Employee;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.sql.Date; // Import java.sql.Date (instead of java.util.Date)

public class EmployeeTableView extends TableView<Employee> {

    public EmployeeTableView() {
        this.setPadding(new Insets(20,20,20,20));
        ObservableList<Employee> data = getEmployeeList();
        // Define table columns
        TableColumn<Employee, Integer> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        idColumn.setPrefWidth(100);

        TableColumn<Employee, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().firstNameProperty().concat(" ").concat(cellData.getValue().lastNameProperty()));
        nameColumn.setPrefWidth(100);

        TableColumn<Employee, Integer> ageColumn = new TableColumn<>("Age");
        ageColumn.setCellValueFactory(new PropertyValueFactory<>("age"));
        ageColumn.setPrefWidth(100);

        TableColumn<Employee, String> addressColumn = new TableColumn<>("Address");
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        addressColumn.setPrefWidth(100);

        TableColumn<Employee, String> phoneNumberColumn = new TableColumn<>("Phone Number");
        phoneNumberColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        phoneNumberColumn.setPrefWidth(150);

        TableColumn<Employee, Date> birthDateColumn = new TableColumn<>("Birth Date");
        birthDateColumn.setCellValueFactory(new PropertyValueFactory<>("birthDate"));
        birthDateColumn.setPrefWidth(100);

        TableColumn<Employee, Character> genderColumn = new TableColumn<>("Gender");
        genderColumn.setCellValueFactory(new PropertyValueFactory<>("gender"));
        genderColumn.setPrefWidth(100);

        // Add columns to table
        this.getColumns().addAll(idColumn, nameColumn, ageColumn, addressColumn, phoneNumberColumn, birthDateColumn, genderColumn);

        // Set data to the table
        this.setItems(data);
    }

    private ObservableList<Employee> getEmployeeList() {
        ObservableList<Employee> list = FXCollections.observableArrayList(
                new Employee("John", "Doe", 30, "123 Main St", "555-1234", new java.sql.Date(System.currentTimeMillis()), 1, 'M'),
                new Employee("Jane", "Smith", 25, "456 Elm St", "555-5678", new java.sql.Date(System.currentTimeMillis()), 2, 'F'),
                new Employee("Sam", "Johnson", 35, "789 Oak St", "555-8765", new java.sql.Date(System.currentTimeMillis()), 3, 'M')
        );
        return list;
    }
}