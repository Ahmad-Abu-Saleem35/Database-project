package Layouts;

import ERDClasses.Insurance;
import JavaFXClasses.Style;
import SqlClass.DatabaseConnection;
import SqlClass.InsuranceDAO;
import TableViews.InsuranceTableView;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.sql.SQLException;

public class InsuranceLayout extends BorderPane {
    InsuranceTableView insuranceTableView = new InsuranceTableView();
    BorderPane borderPane = Style.borderPane();
    VBox vBox = Style.createVBox();
    Button search;
    TextField searchBar;
    InsuranceDAO insuranceDAO = new InsuranceDAO(DatabaseConnection.getConnection());


    public InsuranceLayout() throws SQLException {
        ContextMenu contextMenu = new ContextMenu();
        MenuItem update = new MenuItem("Update");
        MenuItem delete = new MenuItem("Delete");
        contextMenu.getItems().addAll(delete,update);
        insuranceTableView.setOnMouseClicked(e -> {
            contextMenu.show(insuranceTableView, e.getScreenX(), e.getScreenY()); // pops up a menu that contains delete and update when clicking on the table view
        });
        update.setOnAction(e -> {
            handleUpdate();
        });
        delete.setOnAction(e -> {
            Insurance insurance = insuranceTableView.getSelectionModel().getSelectedItem();
            boolean res = Style.showConfirmation("Are you sure you want to delete this item: " + insurance.getID() + "Type: " + insurance.getType());
            if(res) {
                handleDelete(insurance.getID());
            }
        });
        this.setCenter(insuranceTableView);
        Button search = Style.createButton("Search");
        Button insert = Style.createButton("Insert");
        vBox.getChildren().addAll(search,insert);
        borderPane.setCenter(vBox);
        this.setRight(borderPane);
        Button back = new Button("Back");
        back.setOnAction(e->{
            borderPane.setCenter(vBox);

        });
        insert.setOnAction(e->{

            handleInsert();
        });
        HBox topH = new HBox();
        topH.setSpacing(10);
        topH.setAlignment(Pos.BASELINE_RIGHT);
        topH.setPadding(new Insets(10,10,10,10));
        topH.getChildren().add(back);
        borderPane.setTop(topH);

        this.setBottom(Style.search(searchBar,search));
    }

    public void handleSearch(){
        search.setOnAction(e->{
            String res = search.getText();
        });
    }

    public void handleInsert() {
        // Create components
        RadioButton liability = new RadioButton("Liability");
        RadioButton full = new RadioButton("Full Coverage");
        HBox type = Style.createHBox();
        ToggleGroup toggleGroup = new ToggleGroup();
        liability.setToggleGroup(toggleGroup);
        full.setToggleGroup(toggleGroup);
        type.getChildren().addAll(liability, full);
        TextField carID = Style.createTextField("Enter Car ID");

        // Create grid pane
        GridPane gp = Style.createGridPane();
        gp.add(Style.createText("Car ID"), 0, 0);
        gp.add(carID, 1, 0);
        gp.add(Style.createText("Insurance Type"), 0, 1);
        gp.add(type, 1, 1);

        // Create insert button
        Button button = new Button("Insert");
        button.setOnAction(e -> {
            // Call insert action
            insertAction(carID, toggleGroup);
        });

        // Create insert vbox
        VBox insert = Style.createInsertVBox();
        insert.getChildren().addAll(gp, button);

        // Set insert as the center of the border pane
        borderPane.setCenter(insert);
        this.setBottom(Style.search(searchBar,search));
    }

    private void insertAction(TextField carID, ToggleGroup toggleGroup) {
        // Check if the car ID is empty
        if (carID.getText().isEmpty()) {
            showAlert("Please enter Car ID.");
            return; // Exit the method if car ID is empty
        }

        // Check if an insurance type is selected
        if (toggleGroup.getSelectedToggle() == null) {
            showAlert("Please select an Insurance Type.");
            return; // Exit the method if no insurance type is selected
        }

        // All fields are filled, proceed with insertion logic here
        String selectedInsuranceType = ((RadioButton) toggleGroup.getSelectedToggle()).getText();
        System.out.println("Car ID: " + carID.getText());
        System.out.println("Insurance Type: " + selectedInsuranceType);
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    public void handleUpdate(){

    }
    public void handleDelete(int id){
        insuranceDAO.deleteInsurance(id);
    }

}
