package Layouts;

import ERDClasses.Customer;
import JavaFXClasses.Main;
import JavaFXClasses.Manager;
import JavaFXClasses.Style;
import SqlClass.CustomerDAO;
import SqlClass.DatabaseConnection;
import TableViews.CustomerTableView;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.sql.Date;
import java.sql.SQLException;

public class CustomerLayout extends BorderPane {
    CustomerTableView customerTableView = new CustomerTableView();
    BorderPane borderPane = Style.borderPane();
    VBox vBox = Style.createVBox();
    Button search;
    TextField searchBar;
    Button button = new Button("Back");
    CustomerDAO customerDAO  = new CustomerDAO(DatabaseConnection.getConnection());
    public CustomerLayout() throws SQLException {
        ContextMenu contextMenu = new ContextMenu();
        MenuItem update = new MenuItem("Update");
        MenuItem delete = new MenuItem("Delete");
        contextMenu.getItems().addAll(delete,update);
        customerTableView.setOnMouseClicked(e -> {
            contextMenu.show(customerTableView, e.getScreenX(), e.getScreenY()); // pops up a menu that contains delete and update when clicking on the table view
        });
        update.setOnAction(e -> { // handing the update logic, it just takes the information from the table view item and it updates it
            handleUpdate();
        });
        delete.setOnAction(e -> {
            Customer customer = customerTableView.getSelectionModel().getSelectedItem();
            boolean res = Style.showConfirmation("Are you sure you want to delete this item: " + customer.getFirstName() + " " + customer.getLastName() + "\nID: " + customer.getId());
            if(res) {
                handleDelete(customer.getId());
            }
        });
        this.setCenter(customerTableView);
        this.setRight(borderPane);
        Button search = Style.createButton("Search");
        Button insert = Style.createButton("Insert");
        insert.setOnAction(e->handleInsert());
        vBox.getChildren().addAll(search,insert);
        borderPane.setCenter(vBox);
        button.setOnAction(e->{
            borderPane.setCenter(vBox);
        });
        HBox topH = new HBox();
        topH.setSpacing(10);
        topH.setAlignment(Pos.BASELINE_RIGHT);
        topH.setPadding(new Insets(10,10,10,10));
        topH.getChildren().add(button);
        borderPane.setTop(topH);
        this.setBottom(Style.search(searchBar,search));

    }

    public void handleSearch(){
        search.setOnAction(e->{
            String res = search.getText();
        });

    }
    public void handleInsert() {
        // Create text fields, radio buttons, date picker, and grid pane
        TextField[] tf = new TextField[5];
        RadioButton[] radioButtons = new RadioButton[3];
        HBox genders = Style.genders(radioButtons);
        DatePicker datePicker = Style.datePicker();
        GridPane gridPane = Style.customerInfo(tf, genders, datePicker);
        VBox vBox = Style.createVBox();

        // Create insert button
        Button button = new Button("Insert");
        button.setOnAction(e -> {
            // Check if any text field is empty
            boolean anyEmpty = false;
            for (TextField textField : tf) {
                if (textField.getText().isEmpty()) {
                    anyEmpty = true;
                    break;
                }
            }

            // Check if any radio button is not selected
            boolean noGenderSelected = true;
            for (RadioButton radioButton : radioButtons) {
                if (radioButton.isSelected()) {
                    noGenderSelected = false;
                    break;
                }
            }

            // Check if date picker value is null
            boolean dateNotSelected = datePicker.getValue() == null;

            // If any field is empty or not selected, show error message
            if (anyEmpty || noGenderSelected || dateNotSelected) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Please fill in all fields.");
                alert.showAndWait();
            } else {
                // All fields are filled, proceed with insertion logic here
                // For now, just print the values of the text fields, radio buttons, and date picker
                for (TextField textField : tf) {
                    System.out.println(textField.getText());
                }
                for (RadioButton radioButton : radioButtons) {
                    if (radioButton.isSelected()) {
                        System.out.println(radioButton.getText());
                        break;
                    }
                }
                System.out.println(datePicker.getValue());
            }
            String[] names = tf[0].getText().split(" ");
            String firstName = names[0];
            String lastName = names[1];
            String address = tf[1].getText();
            int id = Integer.parseInt(tf[2].getText());
            String lic = tf[4].getText();
            String phone = tf[4].getText();
            int age = Manager.calculateAge(datePicker.getValue());
            if(Manager.isValidAge(age)){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Age must be 18 or above.");
                alert.showAndWait();
                return;
            }
            Date birthDate = Date.valueOf(datePicker.getValue());
            char gen = ' ';
            if(radioButtons[0].isSelected()){
                gen = 'M';
            }else if(radioButtons[1].isSelected()){
                gen = 'F';
            }else if(radioButtons[2].isSelected()){
                gen = 'N';
            }

            Customer customer = new Customer( firstName,  lastName,  age,  address,  phone,  birthDate,  lic,  id, gen);
            if(customerDAO.customerExists(id)){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Customer ID already Exists.");
                alert.showAndWait();
            }
            customerDAO.insertCustomer(customer,Main.getEmpolyee());
        });

        // Add grid pane and insert button to the vbox
        vBox.getChildren().addAll(gridPane, button);
        // Set vbox as the center of the border pane

        borderPane.setCenter(vBox);
    }

    public void handleUpdate(){

    }
    public void handleDelete(int id) {
        boolean deletionSuccessful = customerDAO.deleteCustomer(id);
        if (deletionSuccessful) {
            // Inform the user about successful deletion
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Success");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Customer deleted successfully.");
            successAlert.showAndWait();
        } else {
            // Inform the user about deletion failure
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Failed to delete customer.");
            alert.showAndWait();
        }
    }
}


