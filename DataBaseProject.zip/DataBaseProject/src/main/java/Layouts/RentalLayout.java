package Layouts;

import ERDClasses.Rental;
import JavaFXClasses.Style;
import SqlClass.DatabaseConnection;
import SqlClass.RentalDAO;
import TableViews.RentalTableView;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.sql.SQLException;

public class RentalLayout extends BorderPane {
    RentalTableView rentalTableView = new RentalTableView();
    BorderPane borderPane = Style.borderPane();
    Button search;
    TextField searchBar;
    RentalDAO rentalDAO = new RentalDAO(DatabaseConnection.getConnection());
    VBox vBox = Style.createVBox();
    public RentalLayout() throws SQLException {
        ContextMenu contextMenu = new ContextMenu();
        MenuItem update = new MenuItem("Update");
        MenuItem delete = new MenuItem("Delete");
        contextMenu.getItems().addAll(delete,update);
        rentalTableView.setOnMouseClicked(e -> {
            contextMenu.show(rentalTableView, e.getScreenX(), e.getScreenY()); // pops up a menu that contains delete and update when clicking on the table view
        });
        update.setOnAction(e -> { // handing the update logic, it just takes the information from the table view item and it updates it
            handleUpdate();
        });
        delete.setOnAction(e -> {
            Rental rental = rentalTableView.getSelectionModel().getSelectedItem();
            boolean result = Style.showConfirmation("Are you sure want to delete this rental: " + rental.getRentID() + "\nStart Date: " + rental.getRentDate() + "\nReturn Date: " + rental.getReturnDate());
            if(result){
                handleDelete(rental.getRentID());
            }
        });
        this.setCenter(rentalTableView);
        this.setRight(borderPane);
        borderPane.setCenter(vBox);
        Button back = new Button("Back");
        HBox topH = new HBox();
        topH.setSpacing(10);
        topH.setAlignment(Pos.BASELINE_RIGHT);
        topH.setPadding(new Insets(10,10,10,10));
        topH.getChildren().add(back);
        borderPane.setTop(topH);
        back.setOnAction(e->{
            borderPane.setCenter(vBox);
        });
        Button search = Style.createButton("Search");
        Button insert = Style.createButton("Insert");
        vBox.getChildren().addAll(search,insert);
        insert.setOnAction(e->{
            handleInsert();
        });
        this.setBottom(Style.search(searchBar,search));
    }

    public void handleSearch(){
        search.setOnAction(e->{
            String res = search.getText();
        });

    }
    public void handleInsert() {
        // Create components
        TextField rentID = Style.createTextField("Enter Rent ID");
        DatePicker datePicker = Style.datePicker();
        RadioButton daily = new RadioButton("Daily");
        RadioButton weekly = new RadioButton("Weekly");
        RadioButton yes = new RadioButton("Yes");
        RadioButton no = new RadioButton("No");
        Button button = new Button("Insert");

        // Create toggle groups
        ToggleGroup typeToggleGroup = new ToggleGroup();
        daily.setToggleGroup(typeToggleGroup);
        weekly.setToggleGroup(typeToggleGroup);
        ToggleGroup cancellationToggleGroup = new ToggleGroup();
        yes.setToggleGroup(cancellationToggleGroup);
        no.setToggleGroup(cancellationToggleGroup);

        // Create grid pane
        GridPane gp = Style.createGridPane();
        gp.add(Style.createText("Rent ID"), 0, 0);
        gp.add(rentID, 1, 0);
        gp.add(Style.createText("Until"), 0, 1);
        gp.add(datePicker, 1, 1);
        gp.add(Style.createText("Type"), 0, 2);
        HBox typeHBox = new HBox(daily, weekly);
        typeHBox.setSpacing(10);
        gp.add(typeHBox, 1, 2);
        gp.add(Style.createText("Cancellation"), 0, 3);
        HBox cancellationHBox = new HBox(yes, no);
        cancellationHBox.setSpacing(10);
        gp.add(cancellationHBox, 1, 3);

        // Create insert vbox
        VBox insertRent = Style.createVBox();
        insertRent.getChildren().addAll(gp, button);

        // Set insert as the center of the border pane
        borderPane.setCenter(insertRent);

        // Set action for the insert button
        button.setOnAction(e -> {
            // Call insertion action
            insertAction(rentID, datePicker, typeToggleGroup, cancellationToggleGroup);
        });
        this.setBottom(Style.search(searchBar,search));

    }

    private void insertAction(TextField rentID, DatePicker datePicker, ToggleGroup typeToggleGroup, ToggleGroup cancellationToggleGroup) {
        // Check for empty fields
        if (rentID.getText().isEmpty() || datePicker.getValue() == null || typeToggleGroup.getSelectedToggle() == null || cancellationToggleGroup.getSelectedToggle() == null) {
            showAlert("Please fill in all fields.");
            return;
        }

        // All fields are filled, proceed with insertion logic here
        String type = ((RadioButton) typeToggleGroup.getSelectedToggle()).getText();
        String cancellation = ((RadioButton) cancellationToggleGroup.getSelectedToggle()).getText();
        System.out.println("Rent ID: " + rentID.getText());
        System.out.println("Until: " + datePicker.getValue());
        System.out.println("Type: " + type);
        System.out.println("Cancellation: " + cancellation);
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void handleUpdate(){

    }
    public void handleDelete(int id){
        rentalDAO.deleteRentalContract(id);
    }

}
