package Layouts;

import ERDClasses.Payment;
import JavaFXClasses.Manager;
import JavaFXClasses.Style;
import SqlClass.DatabaseConnection;
import SqlClass.PaymentDAO;
import TableViews.PaymentTableView;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.sql.SQLException;

public class PaymentLayout extends BorderPane {
    PaymentTableView paymentTableView = new PaymentTableView();
    BorderPane borderPane = Style.borderPane();
    Button search;
    TextField searchBar;
    PaymentDAO paymentDAO = new PaymentDAO(DatabaseConnection.getConnection());

    VBox vBox = Style.createVBox();
    public PaymentLayout() throws SQLException {
        ContextMenu contextMenu = new ContextMenu();
        MenuItem update = new MenuItem("Update");
        MenuItem delete = new MenuItem("Delete");
        contextMenu.getItems().addAll(delete,update);
        paymentTableView.setOnMouseClicked(e -> {
            contextMenu.show(paymentTableView, e.getScreenX(), e.getScreenY()); // pops up a menu that contains delete and update when clicking on the table view
        });
        update.setOnAction(e -> {
            handleUpdate();
        });
        delete.setOnAction(e -> {
            Payment payment = paymentTableView.getSelectionModel().getSelectedItem();
            boolean res = Style.showConfirmation("Are you sure you want to delete this payment: " + payment.getPaymentID() + "\nAmount: " + payment.getAmount() + "\nDate: " + payment.getPaydate());
            if(res) {
                handleDelete(payment.getPaymentID());
            }
        });
        this.setCenter(paymentTableView);
        this.setRight(borderPane);
        Button search = Style.createButton("Search");
        Button insert = Style.createButton("Insert");
        vBox.getChildren().addAll(search,insert);
        borderPane.setCenter(vBox);
        Button button = new Button("Back");
        HBox topH = new HBox();
        topH.setSpacing(10);
        topH.setAlignment(Pos.BASELINE_RIGHT);
        topH.setPadding(new Insets(10,10,10,10));
        topH.getChildren().add(button);
        borderPane.setTop(topH);
        button.setOnAction(e->{
            borderPane.setCenter(vBox);
        });
        insert.setOnAction(e->{
            handleInsert();
        });
        this.setBottom(Style.search(searchBar,search));


    }
    public void handleSearch(){
        search.setOnAction(e->{
            String res = search.getText();
        });

    }
    public void handleInsert() {
        // Create components
        TextField cusID = Style.createTextField("Enter Customer ID");
        RadioButton cash = new RadioButton("Cash");
        RadioButton creditCard = new RadioButton("Credit Card");
        RadioButton cheque = new RadioButton("Cheque");
        TextField amount = Style.createTextField("Enter Amount");
        Button button = new Button("Pay");

        // Create toggle group
        ToggleGroup toggleGroup = new ToggleGroup();
        cash.setToggleGroup(toggleGroup);
        creditCard.setToggleGroup(toggleGroup);
        cheque.setToggleGroup(toggleGroup);

        // Create grid pane
        GridPane gp = Style.createGridPane();
        gp.add(Style.createText("Customer ID"), 0, 0);
        gp.add(cusID, 1, 0);
        gp.add(Style.createText("Payment Method"), 0, 1);
        HBox hBox = new HBox(cash, creditCard, cheque);
        hBox.setSpacing(10);
        gp.add(hBox, 1, 1);
        gp.add(Style.createText("Amount"), 0, 2);
        gp.add(amount, 1, 2);

        // Create insert vbox
        VBox paymentInsert = Style.createInsertVBox();
        paymentInsert.getChildren().addAll(gp, button);

        // Set insert as the center of the border pane
        borderPane.setCenter(paymentInsert);

        // Set action for the pay button
        button.setOnAction(e -> {
            // Call insertion action
            insertAction(cusID, toggleGroup, amount);
        });
        this.setBottom(Style.search(searchBar,search));
    }

    private void insertAction(TextField cusID, ToggleGroup toggleGroup, TextField amount) {
        // Check for empty fields
        if (cusID.getText().isEmpty() || amount.getText().isEmpty() || toggleGroup.getSelectedToggle() == null) {
            showAlert("Please fill in all fields.");
            return;
        }
        if(Manager.isNum(amount.getText())){
            showAlert("Invalid Amount.");
            return;
        }
        double amountN = Double.parseDouble(amount.getText());

        // All fields are filled, proceed with insertion logic here
        String paymentMethod = ((RadioButton) toggleGroup.getSelectedToggle()).getText();
        System.out.println("Customer ID: " + cusID.getText());
        System.out.println("Payment Method: " + paymentMethod);
        System.out.println("Amount: " + amount.getText());
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void handleUpdate(){

    }
    public void handleDelete(int id){
        paymentDAO.deletePayment(id);
    }

}
