package Layouts;

import ERDClasses.Employee;
import JavaFXClasses.Style;
import SqlClass.DatabaseConnection;
import SqlClass.EmployeeDAO;
import TableViews.EmployeeTableView;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.sql.SQLException;

public class EmployeeLayout extends BorderPane {
    EmployeeTableView employeeTableView = new EmployeeTableView();
    BorderPane borderPane = Style.borderPane();
    VBox vBox = Style.createVBox();
    Button search;
    TextField searchBar;
    EmployeeDAO employeeDAO = new EmployeeDAO(DatabaseConnection.getConnection());
    public EmployeeLayout() throws SQLException {
        ContextMenu contextMenu = new ContextMenu();
        MenuItem update = new MenuItem("Update");
        MenuItem delete = new MenuItem("Delete");
        contextMenu.getItems().addAll(delete,update);
        employeeTableView.setOnMouseClicked(e -> {
            contextMenu.show(employeeTableView, e.getScreenX(), e.getScreenY()); // pops up a menu that contains delete and update when clicking on the table view
        });
        update.setOnAction(e -> {
            handleUpdate();
        });
        delete.setOnAction(e -> {
            Employee employee = employeeTableView.getSelectionModel().getSelectedItem();
            boolean res = Style.showConfirmation("Are you sure you want to delete this item: " + employee.getFirstName() + " " + employee.getLastName() + "\nID: " + employee.getId());
            if(res){
                handleDelete(employee.getId());

            }
        });

        this.setCenter(employeeTableView);
        Button search = Style.createButton("Search");
        Button insert = Style.createButton("Insert");
        vBox.getChildren().addAll(search,insert);
        borderPane.setCenter(vBox);
        this.setRight(borderPane);
        Button back = new Button("Back");
        back.setOnAction(e->{
            borderPane.setCenter(vBox);
        });
        insert.setOnAction(e->{
            handleInsert();
        });
        HBox topH = new HBox();
        topH.setSpacing(10);
        topH.setAlignment(Pos.BASELINE_RIGHT);
        topH.setPadding(new Insets(10,10,10,10));
        topH.getChildren().add(back);
        borderPane.setTop(topH);

        this.setBottom(Style.search(searchBar,search));
    }

    public void handleSearch(){
        search.setOnAction(e->{
            String res = search.getText();
        });
    }

    public void handleInsert() {
        // Create text fields, radio buttons, date picker, and grid pane
        TextField[] tf = new TextField[4];
        DatePicker datePicker = Style.datePicker();
        RadioButton[] radioButtons = new RadioButton[3];
        HBox genders = Style.genders(radioButtons);
        GridPane gp = Style.employeeBInfo(tf, genders, datePicker);
        VBox insertEmp = Style.createInsertVBox();

        // Create insert button
        Button button = new Button("Insert");
        button.setOnAction(e -> {
            // Check if any text field is empty
            boolean anyEmpty = false;
            for (TextField textField : tf) {
                if (textField.getText().isEmpty()) {
                    anyEmpty = true;
                    break;
                }
            }

            // Check if any radio button is not selected
            boolean noGenderSelected = true;
            for (RadioButton radioButton : radioButtons) {
                if (radioButton.isSelected()) {
                    noGenderSelected = false;
                    break;
                }
            }

            // Check if date picker value is null
            boolean dateNotSelected = datePicker.getValue() == null;

            // If any field is empty or not selected, show error message
            if (anyEmpty || noGenderSelected || dateNotSelected) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Please fill in all fields.");
                alert.showAndWait();
            } else {
                // All fields are filled, proceed with insertion logic here
                // For now, just print the values of the text fields, radio buttons, and date picker
                for (TextField textField : tf) {
                    System.out.println(textField.getText());
                }
                for (RadioButton radioButton : radioButtons) {
                    if (radioButton.isSelected()) {
                        System.out.println(radioButton.getText());
                        break;
                    }
                }
                System.out.println(datePicker.getValue());
            }
        });

        // Add grid pane and insert button to the vbox
        insertEmp.getChildren().addAll(gp, button);

        // Set insertEmp as the center of the border pane
        borderPane.setCenter(insertEmp);
        this.setBottom(Style.search(searchBar,search));
    }
    public void handleUpdate(){

    }

    public void handleDelete(int id){
        employeeDAO.deleteEmployee(id);
    }

}
