package Layouts;

import ERDClasses.Car;
import ERDClasses.Customer;
import JavaFXClasses.Style;
import SqlClass.CarDAO;
import SqlClass.DatabaseConnection;
import TableViews.CarTableView;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.sql.SQLException;

public class CarLayout extends BorderPane {
    CarTableView carTableView = new CarTableView();
    BorderPane borderPane = Style.borderPane();
    Button search;
    TextField searchBar;
    CarDAO carDAO = new CarDAO(DatabaseConnection.getConnection());

    VBox vBox = Style.createVBox();
    public CarLayout() throws SQLException {
        ContextMenu contextMenu = new ContextMenu();
        MenuItem update = new MenuItem("Update");
        MenuItem delete = new MenuItem("Delete");
        contextMenu.getItems().addAll(delete,update);
        carTableView.setOnMouseClicked(e -> {
            contextMenu.show(carTableView, e.getScreenX(), e.getScreenY()); // pops up a menu that contains delete and update when clicking on the table view
        });
        update.setOnAction(e -> { // handing the update logic, it just takes the information from the table view item and it updates it
            handleUpdate();
        });
        delete.setOnAction(e -> {
            Car car = carTableView.getSelectionModel().getSelectedItem();
            boolean res = Style.showConfirmation("Are you sure you want to delete this car: " + car.getCarNo() + "\nModel: " + car.getModel() + "\nCar Color: " + car.getColor());
            if(res){
                handleDelete(car.getCarNo());
            }

        });
        this.setCenter(carTableView);

        Button search = Style.createButton("Search");
        Button insert = Style.createButton("Insert");
        vBox.getChildren().addAll(search,insert);
        insert.setOnAction(e->{
            handleInsert();
        });
        this.setRight(borderPane);
        borderPane.setRight(vBox);
        Button back = new Button("Back");
        HBox topH = new HBox();
        topH.setSpacing(10);
        topH.setAlignment(Pos.BASELINE_RIGHT);
        topH.setPadding(new Insets(10,10,10,10));
        topH.getChildren().add(back);
        borderPane.setTop(topH);

        back.setOnAction(e->{
            borderPane.setCenter(vBox);
        });
        this.setBottom(Style.search(searchBar,search));
    }

    public void handleSearch(){
        search.setOnAction(e->{
            String res = search.getText();
        });

    }

    public void handleInsert() {
        // Create components
        TextField id = Style.createTextField("Enter Car ID");
        TextField model = Style.createTextField("Enter Model");
        TextField rental = Style.createTextField("Enter Rental Price");
        RadioButton[] condition = new RadioButton[3];
        condition[0] = new RadioButton("Good");
        condition[1] = new RadioButton("Average");
        condition[2] = new RadioButton("Bad");
        RadioButton[] colors = new RadioButton[4];
        for (int i = 0; i < colors.length; i++) {
            colors[i] = new RadioButton("Color " + (i + 1));
        }
        Button button = new Button("Enter");

        // Create toggle groups
        ToggleGroup conditionToggleGroup = new ToggleGroup();
        condition[0].setToggleGroup(conditionToggleGroup);
        condition[1].setToggleGroup(conditionToggleGroup);
        condition[2].setToggleGroup(conditionToggleGroup);

        ToggleGroup colorToggleGroup = new ToggleGroup();
        for (RadioButton color : colors) {
            color.setToggleGroup(colorToggleGroup);
        }

        // Create grid pane
        GridPane gp = Style.createGridPane();
        gp.add(Style.createText("Car ID"), 0, 0);
        gp.add(id, 1, 0);
        gp.add(Style.createText("Model"), 0, 1);
        gp.add(model, 1, 1);
        gp.add(Style.createText("Condition"), 0, 2);
        HBox conditionHbox = new HBox(condition);
        conditionHbox.setSpacing(10);
        gp.add(conditionHbox, 1, 2);
        gp.add(Style.createText("Color"), 0, 3);
        HBox colorHbox = new HBox(colors);
        colorHbox.setSpacing(10);
        gp.add(colorHbox, 1, 3);
        gp.add(Style.createText("Rental Price"), 0, 4);
        gp.add(rental, 1, 4);

        // Create insert vbox
        VBox insertCar = Style.createVBox();
        insertCar.getChildren().addAll(gp, button);

        // Set insert as the right of the border pane
        borderPane.setRight(insertCar);

        // Set action for the enter button
        button.setOnAction(e -> {
            // Call insertion action
            insertAction(id, model, conditionToggleGroup, colorToggleGroup, rental);
        });

        this.setBottom(Style.search(searchBar,search));
    }

    private void insertAction(TextField id, TextField model, ToggleGroup conditionToggleGroup, ToggleGroup colorToggleGroup, TextField rental) {
        // Check for empty fields
        if (id.getText().isEmpty() || model.getText().isEmpty() || rental.getText().isEmpty() ||
                conditionToggleGroup.getSelectedToggle() == null || colorToggleGroup.getSelectedToggle() == null) {
            showAlert("Please fill in all fields.");
            return;
        }

        // All fields are filled, proceed with insertion logic here
        String condition = ((RadioButton) conditionToggleGroup.getSelectedToggle()).getText();
        String color = ((RadioButton) colorToggleGroup.getSelectedToggle()).getText();
        System.out.println("Car ID: " + id.getText());
        System.out.println("Model: " + model.getText());
        System.out.println("Condition: " + condition);
        System.out.println("Color: " + color);
        System.out.println("Rental Price: " + rental.getText());
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void handleUpdate(){

    }
    public void handleDelete(int id){

    }

}
