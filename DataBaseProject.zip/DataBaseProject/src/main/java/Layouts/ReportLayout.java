package Layouts;

import JavaFXClasses.Style;
import javafx.geometry.Insets;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class ReportLayout extends BorderPane {
    public ReportLayout(){
        ComboBox<String> comboBox = new ComboBox<>();
        comboBox.setPromptText("Select an option");
        comboBox.setPadding(new Insets(20,20,20,20));
        HBox hBox = new HBox();
        hBox.setPadding(new Insets(10,10,10,10));
        hBox.getChildren().add(comboBox);
        this.setTop(hBox);
    }
}
