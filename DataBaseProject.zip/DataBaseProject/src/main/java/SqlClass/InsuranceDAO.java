package SqlClass;

import ERDClasses.Insurance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class InsuranceDAO {
    private Connection connection;

    public InsuranceDAO(Connection connection) {
        this.connection = connection;
    }

    public void insertInsurance(Insurance insurance) {
        // Check if the associated car exists
        if (!carExists(insurance.getCar_Id())) {
            System.out.println("Associated car with car number " + insurance.getCar_Id() + " does not exist.");
            return;
        }

        String sql = "INSERT INTO Insurance (insurance_id, insurance_type, car_No) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, insurance.getID());
            preparedStatement.setString(2, insurance.getType());
            preparedStatement.setInt(3, insurance.getCar_Id());

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Insurance inserted successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }

    public void deleteInsurance(int insuranceId) {
        // Check if the insurance record exists before deletion
        if (!insuranceExists(insuranceId)) {
            System.out.println("Insurance with ID " + insuranceId + " does not exist.");
            return;
        }

        String sql = "DELETE FROM Insurance WHERE insurance_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, insuranceId);

            int rowsDeleted = preparedStatement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Insurance deleted successfully.");
            } else {
                System.out.println("Insurance with ID " + insuranceId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }
    public void updateInsurance(Insurance insurance, int oldInsuranceId) {
        // Check if the old insurance ID exists before attempting to update
        if (!insuranceExists(oldInsuranceId)) {
            System.out.println("Insurance with ID " + oldInsuranceId + " does not exist.");
            return;
        }

        String sql = "UPDATE Insurance SET insurance_type = ?, car_No = ? WHERE insurance_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, insurance.getType());
            preparedStatement.setInt(2, insurance.getCar_Id());
            preparedStatement.setInt(3, oldInsuranceId);

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Insurance updated successfully.");
            } else {
                System.out.println("Failed to update insurance.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }
    private boolean carExists(int carNo) {
        String sql = "SELECT COUNT(*) FROM Car WHERE car_No = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, carNo);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
        return false;
    }

    private boolean insuranceExists(int insuranceId) {
        String sql = "SELECT COUNT(*) FROM Insurance WHERE insurance_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, insuranceId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
        return false;
    }
    public List<Insurance> searchInsurance(String insuranceType, Integer carNo, Integer insuranceId) {
        List<Insurance> insuranceList = new ArrayList<>();
        try {
            StringBuilder sqlBuilder = new StringBuilder("SELECT * FROM Insurance WHERE 1 = 1");
            List<Object> parameters = new ArrayList<>();

            if (insuranceType != null) {
                sqlBuilder.append(" AND insurance_type = ?");
                parameters.add(insuranceType);
            }
            if (carNo != null) {
                sqlBuilder.append(" AND car_No = ?");
                parameters.add(carNo);
            }
            if (insuranceId != null) {
                sqlBuilder.append(" AND insurance_id = ?");
                parameters.add(insuranceId);
            }

            PreparedStatement preparedStatement = connection.prepareStatement(sqlBuilder.toString());
            for (int i = 0; i < parameters.size(); i++) {
                preparedStatement.setObject(i + 1, parameters.get(i));
            }

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int insuranceIdResult = resultSet.getInt("insurance_id");
                String insuranceTypeResult = resultSet.getString("insurance_type");
                int carNoResult = resultSet.getInt("car_No");

                Insurance insurance = new Insurance(insuranceIdResult, insuranceTypeResult, carNoResult);
                insuranceList.add(insurance);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
        return insuranceList;
    }


}
