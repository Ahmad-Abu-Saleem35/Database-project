package SqlClass;

import ERDClasses.DailyRental;
import ERDClasses.Rental;
import ERDClasses.WeeklyRental;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RentalDAO {
    private Connection connection;

    public RentalDAO(Connection connection) {
        this.connection = connection;
    }

    public void insertRentalContract(Rental contract) {
        // Check if the payment ID exists
        if (!paymentExists(contract.getPayment_ID())) {
            System.out.println("Payment with ID " + contract.getPayment_ID() + " does not exist.");
            return;
        }

        // Check if the car ID exists
        if (!carExists(contract.getCar_Id())) {
            System.out.println("Car with ID " + contract.getCar_Id() + " does not exist.");
            return;
        }

        // Check if the employee ID exists
        if (!employeeExists(contract.getEmployee_Id())) {
            System.out.println("Employee with ID " + contract.getEmployee_Id() + " does not exist.");
            return;
        }

        // Update the availability of the referenced car to false
        updateCarAvailability(contract.getCar_Id(), false);

        // Insert the rental contract into the Rental_Contract table
        String rentalContractSQL = "INSERT INTO Rental_Contract (rent_id, rent_date, return_date, cancellation_details, car_No, payment_id, emp_id) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement rentalContractStatement = connection.prepareStatement(rentalContractSQL, Statement.RETURN_GENERATED_KEYS)) {
            rentalContractStatement.setInt(1, contract.getRentID());
            rentalContractStatement.setDate(2, contract.getRentDate());
            rentalContractStatement.setDate(3, contract.getReturnDate());
            rentalContractStatement.setString(4, contract.getCancellation());
            rentalContractStatement.setInt(5, contract.getCar_Id());
            rentalContractStatement.setInt(6, contract.getPayment_ID());
            rentalContractStatement.setInt(7, contract.getEmployee_Id());

            int rowsInserted = rentalContractStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Rental contract inserted successfully.");
                // Get the generated rent_id
                ResultSet generatedKeys = rentalContractStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int rentId = generatedKeys.getInt(1);
                    // Check if it's a daily or weekly rental and insert into the corresponding table
                    if (contract instanceof DailyRental) {
                        insertDailyRental((DailyRental) contract, rentId);
                    } else if (contract instanceof WeeklyRental) {
                        insertWeeklyRental((WeeklyRental) contract, rentId);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }

    private void insertDailyRental(DailyRental dailyRental, int rentId) {
        String dailyRentalSQL = "INSERT INTO Daily_Rental (rent_id, no_of_days, cancellation_details) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(dailyRentalSQL)) {
            preparedStatement.setInt(1, rentId);
            preparedStatement.setInt(2, dailyRental.getNoOfDays());
            preparedStatement.setString(3, dailyRental.getCancellation());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }

    // Method to insert into Weekly_Rental table
    private void insertWeeklyRental(WeeklyRental weeklyRental, int rentId) {
        String weeklyRentalSQL = "INSERT INTO Weekly_Rental (rent_id, no_of_weeks) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(weeklyRentalSQL)) {
            preparedStatement.setInt(1, rentId);
            preparedStatement.setInt(2, weeklyRental.getNoOfWeeks());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }

    public boolean rentalContractExists(int rentId) {
        String sql = "SELECT COUNT(*) FROM Rental_Contract WHERE rent_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, rentId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0; // Return true if count is greater than 0, indicating the rental contract exists
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
        return false; // Return false if an exception occurs or if no rental contract exists
    }

    public void updateCarAvailability(int carNo, boolean isAvailable) {
        String sql = "UPDATE Car SET isAvailable = ? WHERE car_No = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setBoolean(1, isAvailable);
            preparedStatement.setInt(2, carNo);

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Car availability updated successfully.");
            } else {
                System.out.println("Failed to update car availability.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }

    public void deleteRentalContract(int rentId) {
        // Check if the rental contract exists before attempting to delete
        if (!rentalContractExists(rentId)) {
            System.out.println("Rental contract with ID " + rentId + " does not exist.");
            return;
        }

        // Get the car number associated with the rental contract
        int carNo = getCarNumberForRentalContract(rentId);

        // Update the availability of the associated car to true
        updateCarAvailability(carNo, true);

        // Delete the rental contract from the Rental_Contract table
        String sql = "DELETE FROM Rental_Contract WHERE rent_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, rentId);

            int rowsDeleted = preparedStatement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Rental contract deleted successfully.");
            } else {
                System.out.println("Failed to delete rental contract.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }

    public int getCarNumberForRentalContract(int rentId) {
        String sql = "SELECT car_No FROM Rental_Contract WHERE rent_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, rentId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("car_No");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
        // Return a default value or throw an exception if the car number is not found
        return -1; // or throw new RuntimeException("Car number not found for rental contract ID: " + rentId);
    }

    public void updateRentalContract(Rental contract, int oldRentId) {
        // Check if the old rental contract ID exists before attempting to update
        if (!rentalContractExists(oldRentId)) {
            System.out.println("Rental contract with ID " + oldRentId + " does not exist.");
            return;
        }

        // Check if the car ID exists
        if (!carExists(contract.getCar_Id())) {
            System.out.println("Car with ID " + contract.getCar_Id() + " does not exist.");
            return;
        }

        // Check if the payment ID exists
        if (!paymentExists(contract.getPayment_ID())) {
            System.out.println("Payment with ID " + contract.getPayment_ID() + " does not exist.");
            return;
        }

        // Check if the employee ID exists
        if (!employeeExists(contract.getEmployee_Id())) {
            System.out.println("Employee with ID " + contract.getEmployee_Id() + " does not exist.");
            return;
        }

        // Update the availability of the referenced car if the car number has changed
        if (contract.getCar_Id() != getCarNumberForRentalContract(oldRentId)) {
            updateCarAvailability(getCarNumberForRentalContract(oldRentId), true); // Set previous car's availability to true
            updateCarAvailability(contract.getCar_Id(), false); // Set new car's availability to false
        }

        // Perform the update operation
        String sql = "UPDATE Rental_Contract SET rent_id = ?, rent_date = ?, return_date = ?, cancellation_details = ?, car_No = ?, payment_id = ?, emp_id = ? WHERE rent_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, contract.getRentID());
            preparedStatement.setDate(2, contract.getRentDate());
            preparedStatement.setDate(3, contract.getReturnDate());
            preparedStatement.setString(4, contract.getCancellation());
            preparedStatement.setInt(5, contract.getCar_Id());
            preparedStatement.setInt(6, contract.getPayment_ID());
            preparedStatement.setInt(7, contract.getEmployee_Id());
            preparedStatement.setInt(8, oldRentId);

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Rental contract updated successfully.");
                // Update Daily_Rental or Weekly_Rental if exists
                updateDailyOrWeeklyRental(contract, oldRentId);
            } else {
                System.out.println("Failed to update rental contract.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }

    private void updateDailyOrWeeklyRental(Rental contract, int oldRentId) {
        if (contract instanceof DailyRental) {
            DailyRental dailyRental = (DailyRental) contract;
            String updateDailySQL = "UPDATE Daily_Rental SET no_of_days = ?, cancellation_details = ? WHERE rent_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateDailySQL)) {
                preparedStatement.setInt(1, dailyRental.getNoOfDays());
                preparedStatement.setString(2, dailyRental.getCancellation());
                preparedStatement.setInt(3, oldRentId);
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
                // Handle exceptions accordingly
            }
        } else if (contract instanceof WeeklyRental) {
            WeeklyRental weeklyRental = (WeeklyRental) contract;
            String updateWeeklySQL = "UPDATE Weekly_Rental SET no_of_weeks = ? WHERE rent_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateWeeklySQL)) {
                preparedStatement.setInt(1, weeklyRental.getNoOfWeeks());
                preparedStatement.setInt(2, oldRentId);
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
                // Handle exceptions accordingly
            }
        }
    }
    public List<Rental> searchRentalContracts(String startDate, String endDate, int carNo, int paymentId, int empId) {
        List<Rental> rentalContracts = new ArrayList<>();

        // Construct the SQL query dynamically based on the provided parameters
        StringBuilder sqlBuilder = new StringBuilder("SELECT * FROM Rental_Contract WHERE 1 = 1");
        List<Object> parameters = new ArrayList<>();

        if (startDate != null && !startDate.isEmpty()) {
            sqlBuilder.append(" AND rent_date >= ?");
            parameters.add(startDate);
        }
        if (endDate != null && !endDate.isEmpty()) {
            sqlBuilder.append(" AND return_date <= ?");
            parameters.add(endDate);
        }
        if (carNo > 0) {
            sqlBuilder.append(" AND car_No = ?");
            parameters.add(carNo);
        }
        if (paymentId > 0) {
            sqlBuilder.append(" AND payment_id = ?");
            parameters.add(paymentId);
        }
        if (empId > 0) {
            sqlBuilder.append(" AND emp_id = ?");
            parameters.add(empId);
        }

        // Execute the SQL query with the constructed parameters
        try (PreparedStatement preparedStatement = connection.prepareStatement(sqlBuilder.toString())) {
            // Set parameters for the prepared statement
            for (int i = 0; i < parameters.size(); i++) {
                preparedStatement.setObject(i + 1, parameters.get(i));
            }

            // Execute the query and process the results
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                // Retrieve rental contract details from the result set
                int rentId = resultSet.getInt("rent_id");
                java.sql.Date rentDate = resultSet.getDate("rent_date");
                java.sql.Date returnDate = resultSet.getDate("return_date");
                String cancellationDetails = resultSet.getString("cancellation_details");
                int retrievedCarNo = resultSet.getInt("car_No");
                int retrievedPaymentId = resultSet.getInt("payment_id");
                int retrievedEmpId = resultSet.getInt("emp_id");

                // Create a RentalContract object and add it to the list
                Rental rentalContract = new Rental(returnDate, rentDate, rentId, cancellationDetails, retrievedEmpId, retrievedPaymentId,retrievedCarNo);
                rentalContracts.add(rentalContract);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }

        return rentalContracts;
    }
    public boolean employeeExists(int empId) {
        try {
            String sql = "SELECT COUNT(*) FROM Employee WHERE emp_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, empId);
            ResultSet resultSet = preparedStatement.executeQuery();
            resultSet.next(); // Move cursor to the first row
            int count = resultSet.getInt(1); // Retrieve the value of the first column
            return count > 0; // If count > 0, the employee exists; otherwise, it doesn't
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
            return false; // Return false in case of exceptions
        }
    }
    public boolean carExists(int carNo) {
        String sql = "SELECT COUNT(*) FROM Car WHERE car_No = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, carNo);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
        return false;
    }
    private boolean paymentExists(int paymentId) {
        String sql = "SELECT COUNT(*) FROM Payment WHERE payment_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, paymentId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
        return false;
    }

}
