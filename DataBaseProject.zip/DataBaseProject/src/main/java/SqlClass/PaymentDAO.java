package SqlClass;

import ERDClasses.Payment;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {
    private Connection connection;

    public PaymentDAO(Connection connection) {
        this.connection = connection;
    }
    // Insert method for adding a new payment record

    public void insertPayment(Payment payment) {
        // Check if the payment ID already exists
        if (paymentExists(payment.getPaymentID())) {
            System.out.println("Payment with ID " + payment.getPaydate() + " already exists.");
            return;
        }

        // Check if the customer ID exists
        if (!customerExists(payment.getCustomerId())) {
            System.out.println("Customer with ID " + payment.getCustomerId() + " does not exist.");
            return;
        }

        String sql = "INSERT INTO Payment (payment_id, amount, pay_date, down_payment, total_cost, payment_method, cus_Id) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, payment.getPaymentID());
            preparedStatement.setDouble(2, payment.getAmount());
            preparedStatement.setDate(3, payment.getPaydate());
            preparedStatement.setDouble(4, payment.getDownPay());
            preparedStatement.setDouble(5, payment.getAmount());
            preparedStatement.setString(6, payment.getPaymentMethod());
            preparedStatement.setInt(7, payment.getCustomerId());

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Payment inserted successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }

    // Delete method for removing a payment record based on the payment ID
    public void deletePayment(int paymentId) {
        // Check if the payment ID exists before deletion
        if (!paymentExists(paymentId)) {
            System.out.println("Payment with payment ID " + paymentId + " does not exist.");
            return;
        }

        String sql = "DELETE FROM Payment WHERE payment_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, paymentId);

            int rowsDeleted = preparedStatement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Payment deleted successfully.");
            } else {
                System.out.println("Payment with payment ID " + paymentId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }

    // Method to check if a payment exists based on the payment ID
    private boolean paymentExists(int paymentId) {
        String sql = "SELECT COUNT(*) FROM Payment WHERE payment_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, paymentId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
        return false;
    }

    public void updatePayment(Payment payment, int oldPaymentId) {
        // Check if the old payment ID exists before attempting to update
        if (!paymentExists(oldPaymentId)) {
            System.out.println("Payment with ID " + oldPaymentId + " does not exist.");
            return;
        }

        // Check if the customer ID exists
        if (!customerExists(payment.getCustomerId())) {
            System.out.println("Customer with ID " + payment.getCustomerId() + " does not exist.");
            return;
        }

        String sql = "UPDATE Payment SET payment_id = ?, amount = ?, pay_date = ?, down_payment = ?, total_cost = ?, payment_method = ?, cus_Id = ? "
                + "WHERE payment_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, payment.getPaymentID());
            preparedStatement.setDouble(2, payment.getAmount());
            preparedStatement.setDate(3, java.sql.Date.valueOf(payment.getPaymentMethod()));
            preparedStatement.setDouble(4, payment.getDownPay());
            preparedStatement.setDouble(5, payment.getAmount());
            preparedStatement.setString(6, payment.getPaymentMethod());
            preparedStatement.setInt(7, payment.getPaymentID());
            preparedStatement.setInt(8, oldPaymentId); // Set old payment ID

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Payment updated successfully.");
            } else {
                System.out.println("Failed to update payment.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }

    public List<Payment> searchPayments(String paymentMethod, Double minAmount, Double maxAmount,
                                        LocalDate minPayDate, LocalDate maxPayDate, Double minDownPayment, Double maxDownPayment,
                                        Double minTotalCost, Double maxTotalCost) {
        List<Payment> payments = new ArrayList<>();
        try {
            StringBuilder sqlBuilder = new StringBuilder("SELECT * FROM Payment WHERE 1 = 1");
            List<Object> parameters = new ArrayList<>();

            if (paymentMethod != null) {
                sqlBuilder.append(" AND payment_method = ?");
                parameters.add(paymentMethod);
            }
            if (minAmount != null) {
                sqlBuilder.append(" AND amount >= ?");
                parameters.add(minAmount);
            }
            if (maxAmount != null) {
                sqlBuilder.append(" AND amount <= ?");
                parameters.add(maxAmount);
            }
            if (minPayDate != null) {
                sqlBuilder.append(" AND pay_date >= ?");
                parameters.add(Date.valueOf(minPayDate));
            }
            if (maxPayDate != null) {
                sqlBuilder.append(" AND pay_date <= ?");
                parameters.add(Date.valueOf(maxPayDate));
            }
            if (minDownPayment != null) {
                sqlBuilder.append(" AND down_payment >= ?");
                parameters.add(minDownPayment);
            }
            if (maxDownPayment != null) {
                sqlBuilder.append(" AND down_payment <= ?");
                parameters.add(maxDownPayment);
            }
            if (minTotalCost != null) {
                sqlBuilder.append(" AND total_cost >= ?");
                parameters.add(minTotalCost);
            }
            if (maxTotalCost != null) {
                sqlBuilder.append(" AND total_cost <= ?");
                parameters.add(maxTotalCost);
            }

            PreparedStatement preparedStatement = connection.prepareStatement(sqlBuilder.toString());
            for (int i = 0; i < parameters.size(); i++) {
                preparedStatement.setObject(i + 1, parameters.get(i));
            }

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int paymentId = resultSet.getInt("payment_id");
                Double amount = resultSet.getDouble("amount");
                Date payDate = resultSet.getDate("pay_date");
                double downPayment = resultSet.getDouble("down_payment");
                double totalCost = resultSet.getDouble("total_cost");
                String paymentMethodResult = resultSet.getString("payment_method");
                int customerId = resultSet.getInt("cus_Id");

                Payment payment = new Payment( totalCost,  paymentId,  downPayment,  paymentMethod,  payDate, customerId);
                payments.add(payment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
// Handle exceptions accordingly
        }
        return payments;
    }
    public boolean customerExists(int cusId) {
        try {
            String sql = "SELECT COUNT(*) FROM Customer WHERE cus_Id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, cusId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();

        }
        return false;
    }

}
