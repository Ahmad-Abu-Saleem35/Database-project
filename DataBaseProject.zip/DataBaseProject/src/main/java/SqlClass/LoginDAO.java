package SqlClass;

import ERDClasses.Login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDAO {
    private Connection connection;

    public LoginDAO(Connection connection) {
        this.connection = connection;
    }

    public void insertLogin(Login login) {
        String sql = "INSERT INTO Login (emp_id, password) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, login.getEmp_id());
            preparedStatement.setString(2, login.getPassword());

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Login is correct.");
            } else {
                System.out.println("Failed to login.");
            }
        } catch (SQLException e) {
            System.out.println("Error something wrong: " + e.getMessage());
        }
    }

    public boolean selectLogin(int empId, String password) {
        String sql = "SELECT * FROM Login WHERE emp_id = ? AND password = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, empId);
            preparedStatement.setString(2, password);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    // If a matching login is found, return true
                    return true;
                } else {
                    // If no matching login is found, print a message and return false
                    System.out.println("Login not found for emp id: " + empId);
                    return false;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error in login: " + e.getMessage());
            return false;
        }
    }

}
