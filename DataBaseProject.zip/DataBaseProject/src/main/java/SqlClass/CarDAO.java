        package SqlClass;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ERDClasses.Car;

public class CarDAO {
    private Connection connection;

    public CarDAO(Connection connection) {
        this.connection = connection;
    }

    // Insert car method
    public void insertCar(Car car) {
        // Check if a car with the same primary key already exists
        if (carExists(car.getCarNo())) {
            System.out.println("Car with car_No " + car.getCarNo() + " already exists.");
            return;
        }

        String sql = "INSERT INTO Car (car_No, car_color, rental_price, model, mileage, physical_condition, isAvailable) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, car.getCarNo());
            preparedStatement.setString(2, car.getColor());
            preparedStatement.setDouble(3, car.getRentalPrice());
            preparedStatement.setString(4, car.getModel());
            preparedStatement.setDouble(5, car.getMileage());
            preparedStatement.setString(6, car.getCondition());
            preparedStatement.setBoolean(7, true); // Set isAvailable to true by default

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Car inserted successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }

    // Delete car method
    public void deleteCar(int carNo) {
        // Check if the car exists before attempting to delete
        if (!carExists(carNo)) {
            System.out.println("Car with car_No " + carNo + " does not exist.");
            return;
        }

        String sql = "DELETE FROM Car WHERE car_No = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, carNo);

            int rowsDeleted = preparedStatement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Car deleted successfully.");
            } else {
                System.out.println("Car with car_No " + carNo + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }
    public void updateCar(Car car, int oldCarNo) {
        // Check if the old car number exists before attempting to update
        if (!carExists(oldCarNo)) {
            System.out.println("Car with car_No " + oldCarNo + " does not exist.");
            return;
        }

        // If the new car number is different, check if it exists
        if (car.getCarNo() != oldCarNo && carExists(car.getCarNo())) {
            System.out.println("Car with car_No " + car.getCarNo() + " already exists.");
            return;
        }

        String sql = "UPDATE Car SET car_No = ?, car_color = ?, rental_price = ?, model = ?, mileage = ?, physical_condition = ? " +
                "WHERE car_No = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, car.getCarNo()); // Update car number
            preparedStatement.setString(2, car.getColor());
            preparedStatement.setDouble(3, car.getRentalPrice());
            preparedStatement.setString(4, car.getModel());
            preparedStatement.setDouble(5, car.getMileage());
            preparedStatement.setString(6, car.getCondition());
            preparedStatement.setInt(7, oldCarNo); // Use old car number for WHERE clause

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Car updated successfully.");
            } else {
                System.out.println("Failed to update car.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
    }


    // Method to check if a car exists
    public boolean carExists(int carNo) {
        String sql = "SELECT COUNT(*) FROM Car WHERE car_No = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, carNo);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
        return false;
    }
    public List<Car> searchCars(String model, String carColor, String physicalCondition, double maxRentalPrice) {
        List<Car> cars = new ArrayList<>();
        try {
            StringBuilder sqlBuilder = new StringBuilder("SELECT * FROM Car WHERE 1 = 1");
            List<Object> parameters = new ArrayList<>();

            if (model != null) {
                sqlBuilder.append(" AND model LIKE ?");
                parameters.add("%" + model + "%");
            }
            if (carColor != null) {
                sqlBuilder.append(" AND car_color = ?");
                parameters.add(carColor);
            }
            if (physicalCondition != null) {
                sqlBuilder.append(" AND physical_condition LIKE ?");
                parameters.add("%" + physicalCondition + "%");
            }
            if (maxRentalPrice > 0) {
                sqlBuilder.append(" AND rental_price <= ?");
                parameters.add(maxRentalPrice);
            }

            PreparedStatement preparedStatement = connection.prepareStatement(sqlBuilder.toString());
            for (int i = 0; i < parameters.size(); i++) {
                preparedStatement.setObject(i + 1, parameters.get(i));
            }

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int carNo = resultSet.getInt("car_No");
                String carColorResult = resultSet.getString("car_color");
                double rentalPrice = resultSet.getDouble("rental_price");
                String modelResult = resultSet.getString("model");
                double mileage = resultSet.getDouble("mileage");
                String physicalConditionResult = resultSet.getString("physical_condition");
                boolean isAvailable = resultSet.getBoolean("isAvailable");

                Car car = new Car(carColor, model, physicalCondition, carNo, rentalPrice,isAvailable, (int) mileage);
                cars.add(car);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
        return cars;
    }
    public Car searchCarById(int carNo) {
        Car car = null;
        String sql = "SELECT * FROM Car WHERE car_No = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, carNo);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                String carColor = resultSet.getString("car_color");
                double rentalPrice = resultSet.getDouble("rental_price");
                String model = resultSet.getString("model");
                double mileage = resultSet.getDouble("mileage");
                String physicalCondition = resultSet.getString("physical_condition");
                boolean isAvailable = resultSet.getBoolean("isAvailable");
                 car = new Car(carColor, model, physicalCondition, carNo, rentalPrice,isAvailable, (int) mileage);
            } else {
                System.out.println("Car with car_No " + carNo + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions accordingly
        }
        return car;
    }
}
